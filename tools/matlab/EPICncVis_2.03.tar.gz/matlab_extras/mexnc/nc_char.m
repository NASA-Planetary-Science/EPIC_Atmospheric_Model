function nc_datatype = nc_char()
% NC_CHAR:  returns constant corresponding to NC_CHAR enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_char;
%

nc_datatype = 2;
return



