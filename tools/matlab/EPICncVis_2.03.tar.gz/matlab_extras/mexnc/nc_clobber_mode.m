function mode = nc_clobber_mode()
% NC_CLOBBER_MODE:  returns integer mnemonic for NC_CLOBBER
%
% USAGE:  mode = nc_clobber_mode;
mode = 0;
return


