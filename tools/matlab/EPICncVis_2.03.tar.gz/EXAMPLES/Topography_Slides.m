
clear

slide_type            = 'TOPOGRAPHY-SPHERE';    % 'TOPOGRAPHY' or 'TOPOGRAPHY-SPHERE'

planet                = 'Venus';
experiment_dir        = 'no_forcing';

%
% Optional Parameters:
%
% PresentationSlides    = TRUE or FALSE
% 
% scale_data            = <num>;
% shading_type          = 'interp', 'faceted', or 'flat';
% fig_width             = <num>; 
%
% auto_close_figures   = TRUE or FALSE;


%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC

