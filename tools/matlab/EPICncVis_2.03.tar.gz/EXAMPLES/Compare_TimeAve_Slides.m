
clear

slide_type      = 'COMPARE-TIMEAVE-ZONALAVE_VS_PRESSURE';  % Valid types are COMPARE-TIMEAVE-ZONALAVE 
                                                           %             and COMPARE-TIMEAVE-ZONALAVE_VS_PRESSURE

compare_subplot(1).planet       = 'Venus';
compare_subplot(1).experiment   = 'experiment09';
compare_subplot(1).mat_filename = 'TimeAverageEpicData_Venus';   % Make sure this file has been created using TimeAverageEpicData
compare_subplot(1).title        = 'Full Topography';

compare_subplot(2).planet       = 'Venus_Flat';
compare_subplot(2).experiment   = 'experiment07';
compare_subplot(2).mat_filename = 'TimeAverageEpicData_Venus_Flat';   % Make sure this file has been created using TimeAverageEpicData
compare_subplot(2).title        = 'No Topography';

vars_to_plot.name               = 'u';



%
% Optional Parameters
%
% slides_extract_ik                 = <array>, or 'all'; 
% axis_limits(1:2).mxn              = [xmin xmax ymin ymax];
% xtick                             = <array>;
% ytick                             = <array>;
% XLabel                            = <char>;
% YLabel                            = <char>;
%
% convert_mbar_to_Pa                = TRUE or FALSE;
% extend_surface_data.pressure      = <num>;
% extend_surface_data.units         = 'Pa' or 'mb';
%
% scale_data                        = <num>;
% use_auto_color_map                = TRUE or FALSE;
% zmin                              = <num>;
% zmax                              = <num>;
% colormap_type                     = 'light-gray', 'gray', or 'rbg';
% contour_lines                     = <array>;
% contour_lines_label               = <array>;
%
% fig_pos_mxn                       = [ <num>, <num> ];   
% fig_width_mxn                     = <num>;
% background_color                  = <color>;
%
% check_subplot_time_synch          = TRUE or FALSE;
% display_time_text_box             = TURE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%

 
%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC



