
clear

slide_type      = 'COMPARE-EP_FLUX_DIV';  

compare_subplot(1).planet     = 'Venus';
compare_subplot(1).experiment = 'no_forcing';
compare_subplot(1).title      = 'Forcing Off';

compare_subplot(2).planet     = 'Venus';
compare_subplot(2).experiment = 'forcing';
compare_subplot(2).title      = 'Forcing On';

slides_extract_it             = 1 : 10000;   

%
% Optional Parameters
%
% slides_extract_ik                 = <array>, or 'all'; 
% axis_limits(1:2).mxn              = [xmin xmax ymin ymax];
% use_auto_color_map                = TRUE or FALSE;
% zmin                              = <num>;
% zmax                              = <num>;
%
% xtick                             = <array>;
% ytick                             = <array>;
% XLabel                            = <char>;
% YLabel                            = <char>;
% scale_data                        = <num>;
%
% contour_plot_type                 = 0 for line contours, 1 for filled contours
% contour_lines                     = <array>;
% contour_lines_label               = <array>;
% min_display_resolution            = [xres yres];
%
% fig_width                         = <num>;
% fig_pos_mxn                       = [ <num>, <num> ];   
% fig_width_mxn                     = <num>;
% background_color                  = <color>;
% width_height_ratio                = <ratio>;
% check_subplot_time_synch          = TRUE or FALSE;
%
% display_time_text_box             = TURE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%
 
%
% Add Customizations Here
%
axis_limits(1).mxn            = [ -90 90 300 800];
axis_limits(2).mxn            = [ -90 90 300 800];


%
% Generate Subplot
%
makeSlidesEpicNC


