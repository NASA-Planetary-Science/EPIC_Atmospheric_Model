
  checkEPICncPATHs
  nc=1; iv=1;

  curve(nc).name                   = 'Time Average';
  curve(nc).planet                 = 'Venus';
  curve(nc).experiment             = 'experiment09';
  curve(nc).nc_file_name           = 'extract.nc';
  curve(nc).process_type           = 'TIME_AVERAGE_EPIC_DATA';
  curve(nc).variables(iv).name     = 'u';       iv=iv+1;
  curve(nc).variables(iv).name     = 'v';       iv=iv+1;
  curve(nc).variables(iv).name     = 'hdry';    iv=iv+1;
  curve(nc).variables(iv).name     = 'p3';      iv=iv+1;
  curve(nc).variables(iv).name     = 'theta';   iv=iv+1;
  curve(nc).variables(iv).name     = 'hdry3';   iv=iv+1;
  curve(nc).variables(iv).name     = 'p2';      iv=iv+1;
  curve(nc).variables(iv).name     = 'theta2';  iv=iv+1;
  curve(nc).variables(iv).name     = 't2';      iv=iv+1;
  curve(nc).variables(iv).name     = 't3';      iv=iv+1;
  curve(nc).variables(iv).name     = 'exner3';  iv=iv+1;
  curve(nc).variables(iv).name     = 'mont2';   iv=iv+1;
  curve(nc).variables(iv).name     = 'heat3';   iv=iv+1;
  curve(nc).extract_it             = 'all';
  curve(nc).extract_ik             = 'all';
  curve(nc).convert_Pa_to_mbar     = true;
  nc=nc+1;

  for nc=1:length(curve)
    curve(nc).name = [ curve(nc).name ' - ' curve(nc).planet ];
  end

  save_processed_data_filename     = ['TimeAverageEpicData_' curve(1).planet];

%
% Optional Parameters:
%


%
% Add Customizations Here
%



%
% Process Data and Generate Graph
%
load_input_externally         = true;

PlotEpicDiagnostic


