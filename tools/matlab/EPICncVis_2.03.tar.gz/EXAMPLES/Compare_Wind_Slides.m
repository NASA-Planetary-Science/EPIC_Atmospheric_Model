
clear

slide_type      = 'COMPARE-U-LONSLICE';  % 'COMPARE-U-ZONALAVE', 'COMPARE-V-ZONALAVE', 'COMPARE-U-LONSLICE', 'COMPARE-V-LONSLICE' 

compare_subplot(1).planet     = 'Venus';
compare_subplot(1).experiment = 'no_forcing';
compare_subplot(1).title      = 'No Forcing';

compare_subplot(2).planet     = 'Venus';
compare_subplot(2).experiment = 'forcing';
compare_subplot(2).title      = 'Forcing';

slides_extract_it             = 1 : 10000;   

longitude_slice               = 0;           % (only used by LONSLICE)


%
% Optional Parameters
%
% PresentationSlides                = TRUE or FALSE;
% AppendSlides                      = TRUE or FALSE;
%
% slides_extract_ik                 = <array>, or 'all'; 
% axis_limits(1:2).mxn              = [xmin xmax ymin ymax];
%
% fig_pos_mxn                       = [ <num>, <num> ];   
% fig_width_mxn                     = <num>;
% background_color                  = <color>;
% width_height_ratio                = <ratio>;
%
% check_subplot_time_synch          = TRUE or FALSE;
% display_time_text_box             = TURE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE

 
%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC


