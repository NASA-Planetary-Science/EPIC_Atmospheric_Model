clear

slide_type           = 'SCALAR';                    % 'SCALAR' or 'SCALAR-SPHERE'

planet               = 'Jupiter';
experiment_dir       = 'spots';

slides_extract_it    = 1 : 10000;                   % 'first', 'last', 'all', or <array>
slides_extract_ik    = 'bottom';                    % 'bottom', 'top', or <array>

vars_to_plot         = 'u';

%
% Optional Parameters:
%
% AppendSlides                      = TRUE or FALSE;
% PresentationSlides                = TRUE or FALSE;
% Figures_subdir                    = <directory>;
%
% fig_width                         = <num>;
% background_color                  = <color>;
% axis_limits                       = [min_lon max_lon min_lat max_lat];
% xtick                             = [  ];
% ytick                             = [  ];
% xticklabel                        = [  ];
% yticklabel                        = [  ];
%
% scale_data                        = <num>;
% use_auto_color_map                = TRUE or FALSE;
% zmin                              = <num>;
% zmax                              = <num>;
% colormap_type                     = 'light-gray', 'gray', or 'rbg';
% display_colorbar_fig              = TRUE or FALSE;
%
% display_time_text_box             = TRUE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%

%
% Add Customizations Here
%



%
% Generate Subplot
%
makeSlidesEpicNC


