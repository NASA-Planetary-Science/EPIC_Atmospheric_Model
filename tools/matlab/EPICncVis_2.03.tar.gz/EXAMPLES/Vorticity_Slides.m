
clear

slide_type            = 'VORTICITY';   % 'VORTICITY', 'PVORTICITY', 'VORTICITY-SPHERE', or 'PVORTICITY-SPHERE'

planet                = 'Venus';
experiment_dir        = 'no_forcing';

slides_extract_it    = 1 : 10000;                   % 'first', 'last', 'all', or <array>
slides_extract_ik    = 'bottom';                    % 'bottom', 'top', or <array>

%
% Optional Parameters:
%
% AppendSlides                      = TRUE or FALSE;
% PresentationSlides                = TRUE or FALSE;
% Figures_subdir                    = <directory>;
%
% fig_width                         = <num>;
% use_auto_color_map                = TRUE or FALSE;
% zmin                              = <num>;  
% zmax                              = <num>;
% axis_limits                       = [min_lon max_lon min_lat max_lat];
% xtick                             = [  ];
% ytick                             = [  ];
% xticklabel                        = [  ];
% yticklabel                        = [  ];
% display_colorbar_fig              = TRUE or FALSE;
%
% display_time_text_box             = TRUE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% display_arrow_text_box            = TRUE or FALSE;
% arrow_legend.max_arrow_value      = <num> or <char>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%


%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC


