
clear

slide_type        = 'UVTP-LONSLICE';      % 'UVTP-LONSLICE', 'UVTP-ZONALAVE', or 'UVTP-ZONALMAX'

planet            = 'Venus';
experiment_dir    = 'no_forcing';

slides_extract_it = 1 : 10000;   % 'first', 'last', 'all', or <array>


%
% Optional Parameters
%
% AppendSlides                      = TRUE or FALSE;
% PresentationSlides                = TRUE or FALSE;
% Figures_subdir                    = <directory>;
% PresentationSlides                = TRUE or FALSE;
%
% axis_limits(1:4).mxn              = [xmin xmax ymin ymax];
%
% convert_Pa_to_mbar                = TRUE or FALSE;
% longitude_slice                   = <num>;
% slides_extract_ik                 = <array>, or 'all'
% fig_pos_mxn                       = [ <num>, <num> ];   
% fig_width_mxn                     = <num>;
% background_color                  = <color>;
% width_height_ratio                = <ratio>;
%
% display_time_text_box             = TURE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%

%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC


