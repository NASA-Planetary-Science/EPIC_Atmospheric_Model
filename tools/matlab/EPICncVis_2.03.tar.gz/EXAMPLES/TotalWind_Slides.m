clear

slide_type           = 'WIND';                      % 'WIND', 'WIND-SPHERE', or 'WIND-MULTI-LAYER'

planet               = 'Venus';
experiment_dir       = 'no_forcing';

slides_extract_it    = 1 : 10000;                   % 'first', 'last', 'all', or <array>
slides_extract_ik    = 'bottom';                    % 'bottom', 'top', or <array>

subplot_ik           = [15 18 20];                  % (used only with WIND-MULTI-LAYER)
velocity_scaling_mxn = [25 35 45];                  % (used only with WIND-MULTI-LAYER)

%
% Optional Parameters:
%
% AppendSlides                      = TRUE or FALSE;
% PresentationSlides                = TRUE or FALSE;
% Figures_subdir                    = <directory>;
%
% fig_width                         = <num>;
% axis_limits                       = [min_lon max_lon min_lat max_lat];
% xtick                             = [  ];
% ytick                             = [  ];
% xticklabel                        = [  ];
% yticklabel                        = [  ];
%
% velocity_scaling                  = <num>;  % (m/s)
% vector_arrow_scale                = <num>;
% thin_vector_plot_iters            = <num>;
%
% display_time_text_box             = TRUE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% display_arrow_text_box            = TRUE or FALSE;
% arrow_legend.max_arrow_value      = <num> or <char>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
%

%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC


