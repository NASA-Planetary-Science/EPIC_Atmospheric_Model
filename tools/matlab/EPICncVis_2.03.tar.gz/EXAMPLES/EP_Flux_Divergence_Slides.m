  
clear

slide_type            = 'EP_FLUX_DIV';

planet                = 'Venus';
experiment_dir        = 'no_forcing';

slides_extract_it     = 1 : 10000;   
slides_extract_ik     = 'all'; 

%
% Optional Parameters:
%
% AppendSlides                      = TRUE or FALSE;
% PresentationSlides                = TRUE or FALSE;
% Figures_subdir                    = <directory>;
%
% contour_plot_type                 = 0 or 1;
% num_contour_lines                 = <num>;
% logarithmic_plot                  = TRUE or FALSE;
% min_logarithmic_limit             = <num>;
%
% fig_width                         = <num>;
% use_auto_color_map                = TRUE or FALSE;
% zmin                              = <num>;  
% zmax                              = <num>;
% axis_limits                       = [min_lon max_lon min_lat max_lat];
% xtick                             = [  ];
% ytick                             = [  ];
% xticklabel                        = [  ];
% yticklabel                        = [  ];
%
% display_colorbar_fig              = TRUE or FALSE;
% display_time_text_box             = TURE or FALSE;
% time_text_box.units               = 'decades', 'years', 'days', 'hours', 'minutes', or 'seconds' ;
% time_text_box.adjust_display_time = <num>
%
% output_file_format(:).name        = 'none', 'screen', 'ps', 'eps', 'ill', 'pdf', 'jpeg', 'tiff', or 'png'
% auto_close_figures                = TRUE or FALSE
% 

%
% Add Customizations Here
%


%
% Generate Subplot
%
makeSlidesEpicNC


