

   %
   % Add EPICncVis to the Matlab path 
   %
   addpath( [EPIC_MATLAB_SRC_PATH '/EPICncVisTools'] )
   addpath( [EPIC_MATLAB_SRC_PATH '/EPICncVis'     ] )
   
   %
   % Check compatibility
   %
   printEPICncVisVersion();
   checkMatlabVersion();
   checkEPICncPATHs();

   
   %
   % Add additional libraries to the Matlab path necessary for running EPICncVis.
   %
   addpath( [EPIC_MATLAB_SRC_PATH '/matlab_extras/mexnc'                          ], '-end' )
   addpath( [EPIC_MATLAB_SRC_PATH '/matlab_extras/netcdf_toolbox'                 ], '-end' )
   addpath( [EPIC_MATLAB_SRC_PATH '/matlab_extras/netcdf_toolbox/netcdf'          ], '-end' )
   addpath( [EPIC_MATLAB_SRC_PATH '/matlab_extras/netcdf_toolbox/netcdf/nctype'   ], '-end' )
   addpath( [EPIC_MATLAB_SRC_PATH '/matlab_extras/netcdf_toolbox/netcdf/ncutility'], '-end' )
   
