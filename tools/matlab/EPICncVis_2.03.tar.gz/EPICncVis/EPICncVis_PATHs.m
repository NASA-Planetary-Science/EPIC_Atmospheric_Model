%
% Set the paths required for EPICncVis :
%
%   EPIC_MATLAB_SRC_PATH
%   EPIC_MATLAB_USER_PATH
%   EPIC_DATA_PATH
%
 
EPIC_MATLAB_SRC_PATH   = '/home/dowling/epic/tools/matlab/EPICncVis_2.03';
EPIC_MATLAB_USER_PATH  = '/home/dowling/matlab';
EPIC_DATA_PATH         = '/home/dowling/';
 
 
