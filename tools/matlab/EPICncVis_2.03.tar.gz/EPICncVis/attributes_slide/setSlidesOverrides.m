
ip = 1;


%
% Create makeSlidesEpicNC_overrides, if it does not exist
%
if length( who('makeSlidesEpicNC_overrides') )==0
  makeSlidesEpicNC_overrides = ' ';
end


%
% Structures
%
%if isfield( time_text_box, 'units' )
% makeSlidesEpicNC_overrides = [ makeSlidesEpicNC_overrides 'time_text_box.units     = ''' time_text_box.units ''';' ];
%end
%if isfield( time_text_box, 'adjust_display_time' )
%   makeSlidesEpicNC_overrides = [makeSlidesEpicNC_overrides ...
%                                 'time_text_box.adjust_display_time = ' num2str(time_text_box.adjust_display_time) ';'] ; 
%end
prefs_to_keep(ip).name = 'time_text_box';                               ip=ip+1;


%
% Scalars and Arrays
%
prefs_to_keep(ip).name = 'use_auto_color_map';                          ip=ip+1;
prefs_to_keep(ip).name = 'zmin';                                        ip=ip+1;
prefs_to_keep(ip).name = 'zmax';                                        ip=ip+1;
prefs_to_keep(ip).name = 'contour_plot_type';                           ip=ip+1;
prefs_to_keep(ip).name = 'num_contour_lines';                           ip=ip+1;
prefs_to_keep(ip).name = 'contour_lines';                               ip=ip+1;
prefs_to_keep(ip).name = 'contour_lines_label';                         ip=ip+1;
prefs_to_keep(ip).name = 'min_display_resolution';                      ip=ip+1;
prefs_to_keep(ip).name = 'postPlot';                                    ip=ip+1;
prefs_to_keep(ip).name = 'convert_Pa_to_mbar';                          ip=ip+1;
prefs_to_keep(ip).name = 'convert_mbar_to_Pa';                          ip=ip+1;
prefs_to_keep(ip).name = 'scale_data';                                  ip=ip+1;
prefs_to_keep(ip).name = 'XLabel';                                      ip=ip+1;
prefs_to_keep(ip).name = 'YLabel';                                      ip=ip+1;
prefs_to_keep(ip).name = 'xtick';                                       ip=ip+1;
prefs_to_keep(ip).name = 'ytick';                                       ip=ip+1;
prefs_to_keep(ip).name = 'xticklabel';                                  ip=ip+1;
prefs_to_keep(ip).name = 'yticklabel';                                  ip=ip+1;
prefs_to_keep(ip).name = 'display_colorbar_fig';                        ip=ip+1;
prefs_to_keep(ip).name = 'display_time_text_box';                       ip=ip+1;
prefs_to_keep(ip).name = 'Extract_FromMatFile';                         ip=ip+1;
prefs_to_keep(ip).name = 'extend_surface_data';                         ip=ip+1;

for ip=1:length(prefs_to_keep)
  if length(who(prefs_to_keep(ip).name))
    if ischar( eval(prefs_to_keep(ip).name) )
      clear name value
      name = prefs_to_keep(ip).name;
      value = eval(prefs_to_keep(ip).name);
      for ival=length(value):-1:1
        if strcmp( value(ival), '''' )
          for ivl=length(value)+1:-1:ival+1
            value(ivl) = value(ivl-1);
          end
        end
      end
      makeSlidesEpicNC_overrides = [ makeSlidesEpicNC_overrides name ' = ''' value ''';' ];

    elseif isstruct( eval(prefs_to_keep(ip).name) )
      clear struct_field_names
      struct_field_names = fieldnames( eval(prefs_to_keep(ip).name) );
      for isfn=1:length(struct_field_names)
        clear name value
        name = [prefs_to_keep(ip).name '.' struct_field_names{isfn}];
        value = eval(name);
        if ischar( value )
          makeSlidesEpicNC_overrides = [ makeSlidesEpicNC_overrides name ' = ''' value ''';' ];
        else
          makeSlidesEpicNC_overrides = [ makeSlidesEpicNC_overrides name ' = [' num2str(value) '];' ];
        end
      end

    else
      makeSlidesEpicNC_overrides = [ makeSlidesEpicNC_overrides prefs_to_keep(ip).name           ...
                                                 ' = [' num2str(eval(prefs_to_keep(ip).name)) '];' ];
    end
  end
end

clear prefs_to_keep 
