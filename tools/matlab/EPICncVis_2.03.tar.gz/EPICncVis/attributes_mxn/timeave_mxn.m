
%
% Side attributes
%
checkEPICncPATHs
if length(who('root_data_dir'))==FALSE
  root_data_dir         = [EPIC_DATA_PATH slash]; 
end
if length(who('planet'))==FALSE
  planet                = 'Venus';
end
if length(who('experiment_dir'))==FALSE
  experiment_dir        = 'experiment06';
end

nc_file_directory     = [root_data_dir planet slash experiment_dir];
tmp_file_name         = getFileNames( 'extract', '.nc', nc_file_directory);
nc_file_name          = [ tmp_file_name(2:length(tmp_file_name))  tmp_file_name(1) ];


%
% PlotEpicNC attributes
%
PlotData              = 'PlotEpicNC';

Title                 = ' ';
YLabel                = ' ';
extract_ik            = 'all'; 
AxisFontSize          = 8 * max(fig_width_mxn) / 420;
display_text_box      = FALSE;
display_time_text_box = FALSE; 

if length(who('longitude_slice')) == 0
  longitude_slice       = 0.0;
end

if length(who('makeSlidesEpicNC_overrides'))
   eval( makeSlidesEpicNC_overrides );
end 

if length(who('plot_type'))==0
   plot_type = 'LONG-SLICE-LINE';
end


