
function offset = JOFFSET()

global JLO using_one_based_arrays;

offset = (1-JLO)*using_one_based_arrays;

