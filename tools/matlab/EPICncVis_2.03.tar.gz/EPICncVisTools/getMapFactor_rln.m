function rln = getMapFactor_rln( lat, re, rp )

rln  = re/sqrt( 1.0 + (rp/re*tan(lat))^2.0 );


