function epic_vars = getEpicVarFromMatFile( vars, mat_file )

TRUE=1;  FALSE=0;

if nargin<2
  error(' Missing input : vars(:).name, mat_file')
end

eval(['load ' mat_file '.mat  ave_epic_vars'])

if length(who('ave_epic_vars'))==0
  error([' Variable "ave_epic_vars" does not exist in ' mat_file '.'])
end

iev=1;
for iv=1:length(vars)

  var_found=FALSE;
  for iav=1:length(ave_epic_vars)
    if strcmp( ave_epic_vars(iav).name, vars(iv).name )
      epic_vars(iev) = ave_epic_vars(iav);
      iev=iev+1;
      var_found=TRUE;
    end
  end
  
  if not( var_found )
    warning([' Variable "' vars(iv).name '" does not exist in ave_epic_vars.'])
  end

end
