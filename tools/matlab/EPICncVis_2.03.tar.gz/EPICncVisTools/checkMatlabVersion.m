function checkMatlabVersion()
%
% function checkMatlabVersion()
%
%  Function displays a warning message if an outdated version
%   of Matlab is being used.
%

v=version;
n=str2num(v(1:3));
if n < 7.1
  warning on
  warning(' ');
  fprintf('\n');
  fprintf( 'EPIC visualization has not been tested on versions of Matlab prior to 7.1. \n' );
  fprintf( 'Proceed at your own risk! \n' );
  fprintf('\n');
end


