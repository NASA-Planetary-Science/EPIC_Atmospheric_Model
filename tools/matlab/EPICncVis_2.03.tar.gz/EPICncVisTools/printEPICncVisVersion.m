function printEPICncVisVersion() 
% 
% function printEPICncVisVersion() 
% 
%  Function displays the current version of EPICncVis. 
% 
 
VERSION = 'EPICncVis_2.03'; 
 
fprintf([' Using ' VERSION ' .....
']); 
 
