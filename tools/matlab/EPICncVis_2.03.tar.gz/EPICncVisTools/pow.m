function out = pow(a,b)
%
% Emulates the cmath routine pow() by returning a^b
%
%   Usage:  out = pow(a,b)
%
if nargin<2
   error(' 2 input arguments required')
end

out = a^b;

