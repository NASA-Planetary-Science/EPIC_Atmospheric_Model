
function out = convertToDouble( data )

out = feval( @double, data );


