function dir_name = getThisDirectoryName()

TRUE=1;  FALSE=0;

dir_name = pwd;

if length(dir_name)>1
  ic=length(dir_name)+1;
  slash_found=FALSE;
  while slash_found==FALSE  &  ic>1
    ic=ic-1;
    if strcmp( dir_name(ic), slash )
      slash_found=TRUE;
    end
  end
  if slash_found
    dir_name = dir_name( ic+1 : length(dir_name) );
  end
end
