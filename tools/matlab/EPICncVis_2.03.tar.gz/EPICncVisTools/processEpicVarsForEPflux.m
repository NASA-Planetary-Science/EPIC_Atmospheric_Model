

if not( isempty(epic_vars) )  |  not( isempty(slides_epic_vars) )

  if length(who('epic_vars')) > 0
     tmp_epic_vars = epic_vars;
  elseif length(who('slides_epic_vars')) > 0
     tmp_epic_vars = slides_epic_vars;
  else
     error(' Can not find epic_vars')
  end


  [ep_flux_y, ep_flux_z, ep_flux_div, ep_theta, ep_theta2] = getEPfluxVector( tmp_epic_vars, nc_file(1).pntr, 'last' );
%size(ep_flux_div)
%length(ep_theta2)
%length( getNCvardata(nc_file(1).pntr, 'lat_hdry' ) )

  epf_plot_time = tmp_epic_vars(1).time;

  vars_to_extract  = vars_to_plot;
  clear tmp_epic_vars vars_to_plot
  vars_to_plot.name = 'EP_FLUX_DIV';
  N=size(ep_flux_div);

  tmp_epic_vars.name          = 'EP_FLUX_DIV';
  tmp_epic_vars.units         = 'm / s^2';
  tmp_epic_vars.dim(1).name   = 'time';
  tmp_epic_vars.dim(2).name   = 'NA';
  tmp_epic_vars.dim(3).name   = 'ep_theta2';
  tmp_epic_vars.dim(4).name   = 'lat_hdry';
  %tmp_epic_vars.data(1,1,:,:) = max( abs( ep_flux_div ), 5*10^-5 );
  %tmp_epic_vars.data(1,1,:,:) = abs( ep_flux_div );
  tmp_epic_vars.data(1,1,:,:) = ep_flux_div;
  tmp_epic_vars.time          = epf_plot_time;
  tmp_epic_vars.tlo=1;  tmp_epic_vars.thi=1;
  tmp_epic_vars.klo=1;  tmp_epic_vars.khi=1;
  tmp_epic_vars.jlo=1;  tmp_epic_vars.jhi=N(1);
  tmp_epic_vars.ilo=1;  tmp_epic_vars.ihi=N(2);

  if length(who('epic_vars')) > 0
     clear epic_vars
     epic_vars = tmp_epic_vars;
  end
  if length(who('slides_epic_vars')) > 0
     clear slides_epic_vars
     slides_epic_vars = tmp_epic_vars;
  end
  clear tmp_epic_vars

  tmp_extract_ik = extract_ik;
  if length(who('slides_extract_ik')) > 0
    tmp_slides_extract_ik = slides_extract_ik;
  end

  extract_ik=1;
  slides_extract_ik=1;
  
else
  extract_it = -1;
  extract_ik = -1;

end

