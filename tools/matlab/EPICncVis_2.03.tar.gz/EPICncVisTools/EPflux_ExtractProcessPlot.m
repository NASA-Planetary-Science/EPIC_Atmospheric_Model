
%
% Extract
%
if ischar(slides_extract_it)
  ex_it = slides_extract_it;
else
  ex_it = slides_extract_it(slide_count-slides_extract_it(1)+1);
end
[slides_epic_vars, dimensions, nc_file] = ExtractEpicNCdata( filepath , vars_to_plot, ex_it, slides_extract_ik ); 
epic_vars = slides_epic_vars;                              


%
% Process
%
processEpicVarsForEPflux

   % (Reset Units for Color Bar)
   reset_units = 'm / s^2';
   %reset_units = 'x10^{-5} m / s^2';
   
   epic_vars(1).units = reset_units;
   slides_epic_vars(1).units = reset_units;
   
%
% Plot
%
if extract_it>-1
   PlotEpicNC

   vars_to_plot=vars_to_extract;  
   slides_extract_ik=tmp_slides_extract_ik;  
   extract_ik=tmp_extract_ik;  
else
   plot_success=FALSE; 
end; 


