
function char_array = remove_sloppy_characters( char_array )
%
%  function removes the '\0' characters that are appended to character
%   strings read from netcdf files. 
%

for ic=length(char_array)-1 : -2 : 1
  if char_array(ic:ic+1) == '\0'
     char_array(ic:ic+1) = [];
  end
end

return

