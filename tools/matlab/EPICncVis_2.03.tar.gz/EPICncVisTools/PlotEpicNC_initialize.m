%clear

%
% Definitions
%
run_directory = pwd;

TRUE=1; FALSE=0;
OFF = 0; ON=1;

SetFile       = TRUE;
SetOutput     = TRUE;
ExtractNCdata = TRUE; 

% the following options are set prior to executing this script
load_files_externally_exists       = length( who('load_files_externally') );
load_comparisons_externally_exists = length( who('load_comparisons_externally') );
extract_ncfile_externally_exists   = length( who('extract_ncfile_externally') );
  
if ( load_files_externally_exists==TRUE )
   if ( load_files_externally==TRUE )
      SetFile = FALSE;
   end
end

if ( load_comparisons_externally_exists==TRUE )
   if ( load_comparisons_externally==TRUE )
      SetOutput = FALSE;
   end
end

if ( extract_ncfile_externally_exists==TRUE )
   if ( extract_ncfile_externally==TRUE )
      ExtractNCdata = FALSE;
   end
end


