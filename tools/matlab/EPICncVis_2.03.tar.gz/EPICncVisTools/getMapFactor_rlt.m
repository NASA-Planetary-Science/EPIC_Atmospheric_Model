function rlt = getMapFactor_rlt( lat, re, rp )

rln = getMapFactor_rln( lat, re, rp );  
rlt  = rln/( cos(lat)*( sin(lat)^2.0 + (re/rp*cos(lat))^2.0 ));          

