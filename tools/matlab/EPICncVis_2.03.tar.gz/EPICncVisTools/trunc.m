function out=trunc(num,p)
%
% function trunc(num,p)
%
% function rounds the number "num" to its
%  "p"th decimal place.
%

if nargin<2, p=0; end

out=round(num*10^p)/10^p;
return
