
function grid_obj = set_dsgth(grid_obj)
 
global KLO KHI

  %
  % Calculate differential and its reciprocal for sigmatheta.
  %

  grid_obj.dsgth(KLO:2*KHI+2 +1) = 0.0;

  %for (K = KLO-1; K <= KHI; K++)  
  for k = KLO-1 : KHI
    K = k+1;
    kk = 2*k;
    KK = kk+1;
    if (k == 0)  
      grid_obj.dsgth(KK+1) = grid_obj.sigmatheta(KK+1)-grid_obj.sigmatheta(KK+2);
    elseif (k == KHI)  
      grid_obj.dsgth(KK+1) = grid_obj.sigmatheta(KK  )-grid_obj.sigmatheta(KK+1);
    else  
      grid_obj.dsgth(KK+1) = grid_obj.sigmatheta(KK  )-grid_obj.sigmatheta(KK+2);
    end

    if (grid_obj.dsgth(KK+1) > 0.0)  
      grid_obj.dsgth_inv(KK+1) = 1.0/grid_obj.dsgth(KK+1);
    else  
      error(['grid_obj.dsgth(kk=' num2str(KK+1) ')=' num2str(grid_obj.dsgth(KK+1)) ]) 
    end
  end

  %for (K = KLO; K <= KHI; K++)  
  for k = KLO : KHI
    K = k+1;
    kk = 2*k;
    KK = kk+1;
    grid_obj.dsgth(KK) = grid_obj.sigmatheta(KK-1)-grid_obj.sigmatheta(KK+1);

    if (grid_obj.dsgth(KK) > 0.0)  
      grid_obj.dsgth_inv(KK) = 1.0/grid_obj.dsgth(KK);
    else 
      error(['grid_obj.dsgth(kk=' num2str(KK) ')=' num2str(grid_obj.dsgth(KK)) ]) 
    end
  end

