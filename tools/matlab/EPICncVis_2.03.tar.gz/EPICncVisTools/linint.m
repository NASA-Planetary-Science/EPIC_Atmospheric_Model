
function ans = linint( xx, tab_x, tab_y, ki )
%
% Evaluates linear interpolation using same arguments as splint(),
% to make it easy to switch between the two.
%
% (code translated from epic_funcs_util.c)
%

  dx = tab_x(ki+1) - tab_x(ki);
  ans = tab_y(ki) + (tab_y(ki+1) - tab_y(ki))*(xx - tab_x(ki))/dx;
  

