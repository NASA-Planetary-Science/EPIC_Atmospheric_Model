
function ATTRIBUTE_PATH = getAttributePath()


tmp_filename = 'attribute_path';
ep_id = fopen( tmp_filename );

while ep_id ~= -1
   fclose(ep_id);
   tmp_filename = [tmp_filename '0'];
   ep_id = fopen( tmp_filename );
end

unix(['echo $ML_ATTRIBUTE_PATH > ' tmp_filename]);

ep_id = fopen( tmp_filename );
ATTRIBUTE_PATH = fgetl( ep_id );
fclose( ep_id );

if length(ATTRIBUTE_PATH)==0
  error('The environment variable ML_ATTRIBUTE_PATH is not set.')
end

eval(['delete ' tmp_filename])

