
function writeFig2Bitmap(filename)
%
% function writeFig2Bitmap( filename )
%
%   Routine writes the current figure to a bitmap named [filename '.bmp'].
%
%   see also:   printToFile()
%

if nargin<1
  error(' A filename must be specified:  writeFig2Bitmap(filename)')
end

rect=get(gcf,'Position');
rect(1:2)=[0.001 0.001];              %Pixel Coord. of Lower Left Corner
capture = getframe(gcf,rect);
imwrite( capture.cdata, [filename '.bmp']);

