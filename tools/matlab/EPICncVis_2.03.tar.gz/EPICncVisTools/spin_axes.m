function spin_axes( dln, dlt, num_revs )
%
%  function spin_axes( dln, dlt, num_revs )
%
%   defaults:   dln      = 5.0;
%               dlt      = 0.0;
%               num_revs = 1;
%

if nargin<3
  num_revs = 1;
end
if nargin<2
  dlt = 0.0;
end
if nargin<1
  dln = 5.0;
end

%delay = 0.15;  % (seconds)
delay = 0.05;  % (seconds)

%
% Longitudinal Rotation
%
figure(gcf)
for iln=1:360.0/abs(dln)*num_revs
   camorbit(dln, dlt);
   pause( delay );
end
