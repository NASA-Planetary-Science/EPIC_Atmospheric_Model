
function offset = IOFFSET()

global ILO using_one_based_arrays

offset = (1-ILO)*using_one_based_arrays;

