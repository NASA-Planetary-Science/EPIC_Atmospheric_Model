
               deg = pi/180.0;
	       for ii=ILO:IHI
                  I = ii+IOFFSET();
                  lon = longitude(I)*deg ;
	          for jj=JLO:JHI
                     J = jj+JOFFSET();
                     lat = latitude(J)*deg ;

	             sphere_plot_x(J,I) = cos( lat ) * cos( lon-pi/2 );
	             sphere_plot_y(J,I) = cos( lat ) * sin( lon-pi/2 );
	             sphere_plot_z(J,I) = sin( lat ) * buldge_factor; 

                     if vector_plot==TRUE
                        u_dat =  u_plot_data(J,I) ;
                        v_dat =  v_plot_data(J,I) ;
                        sphere_u_data(J,I) = -u_dat*cos( lat )*sin( lon-pi/2 ) ...
                                           -  v_dat*sin( lat )*cos( lon-pi/2 );
                        sphere_v_data(J,I) =  u_dat*cos( lat )*cos( lon-pi/2 ) ...
                                           -  v_dat*sin( lat )*sin( lon-pi/2 );
                        sphere_w_data(J,I) =  v_dat*cos( lat );
                     end
	          end
	       end
               clear lon lat u_dat v_dat

