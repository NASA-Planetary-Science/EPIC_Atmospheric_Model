function [cs chan] = contourfpm( x, y, data, cont_lines )
%
% function [cs chan] = contourfpm( x, y, data, cont_lines )
%
% Plots contours using the Matlab tool "contourf", and 
%  then alters negative isolines to be displayed as dashed.
%

[cs chan]=contourf( x, y, data, cont_lines);

%cont_levels = get(chan, 'LevelList');
cont_ids    = get(chan, 'Children' );
for icd=1:length(cont_ids)
  if get(cont_ids(icd), 'FaceVertexCData') < 0
    %set( cont_ids(icd), 'LineStyle', ':' );
    %set( cont_ids(icd), 'LineStyle', '-.' );
    set( cont_ids(icd), 'LineStyle', '--' );
  else
    set( cont_ids(icd), 'LineStyle', '-' );
  end
end

