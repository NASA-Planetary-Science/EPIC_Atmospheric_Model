
function out = slash

if strcmp(computer,'PCWIN')==1
   out = '\';
else
   out = '/';
end

