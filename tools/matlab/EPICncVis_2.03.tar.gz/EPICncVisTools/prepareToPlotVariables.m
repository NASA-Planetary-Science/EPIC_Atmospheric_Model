
%
% Prepare extract_it and extract_ik
%
if strcmp(extract_it,'first')
  clear extract_it
  nc_file = nc_file(1);
  extract_it = 1;
elseif strcmp(extract_it,'last')
  clear extract_it
  nc_file = nc_file(length(nc_file));
  extract_it = length( var(nc_file.pntr,'time')  );
elseif strcmp(extract_it,'all')  |   extract_it==-1
  clear extract_it
  extract_it = 1:length( var(nc_file(1).pntr,'time')  );
  for inc=2:1:num_files
     num_new_it = length( var(nc_file(inc).pntr,'time') );
     first_it = extract_it(length(extract_it)) + 1;
     extract_it(length(extract_it)+1 : length(extract_it)+num_new_it) = first_it : first_it+num_new_it-1;
  end
elseif isnumeric(extract_it)
  extract_it = sort(extract_it);
else
  error('  Invalid input:  extract_it')
end


if strcmp(extract_ik,'top')
  clear extract_ik
  extract_ik = 1;
elseif strcmp(extract_ik,'bottom')
  clear extract_ik
  extract_ik = length( var(nc_file(1).pntr,'sigmatheta_u')  );
elseif strcmp(extract_ik,'all')
  clear extract_ik
  extract_ik = 1:length( var(nc_file(1).pntr,'sigmatheta_u')  );
else
  extract_ik = sort(extract_ik);
end


if strcmp(opaque_ik,'top')
  clear opaque_ik
  opaque_ik = 1;
elseif strcmp(opaque_ik,'bottom')
  clear opaque_ik
  opaque_ik = length( var(nc_file(1).pntr,'sigmatheta_u')  );
elseif strcmp(opaque_ik,'all')
  clear opaque_ik
  opaque_ik = 1:length( var(nc_file(1).pntr,'sigmatheta_u')  );
end


