   

      apos_no_cb = get(gca,'Position');
      fpos_no_cb = get( gcf,'Position');

      if ( color_bar_orientation == 1 )
         colorbar('horiz');
         colorbar_handle = findobj( 'Tag', 'Colorbar' );
         %cb_fig = length(colorbar_handle);
         cb_fig = 1;
         cbpos = get( colorbar_handle(cb_fig), 'Position');

         fig_has_title = FALSE;
         if length(who('cbar_leave_room_for_title'))==1
            if cbar_leave_room_for_title == TRUE
               fig_has_title = TRUE;
            end
         end
         
         cbpos(4)= 0.025;
         if ( maximize_display == TRUE ) 
            fig_has_title = FALSE;
            vcbar_gap = 0.15;  
            cbwidth = color_bar_width;
            cbleft  = 0.5*(1.0-color_bar_width); 
            cbbottom = 0.75*cbpos(2);
         else 
            apos = get( gca, 'Position');
            cbwidth = color_bar_width * apos(3);
            cbleft  = apos(1) + 0.5*(apos(3)-cbwidth);
            if fig_has_title == TRUE
               vcbar_gap = 0.15;  
               cbbottom = 0.45*cbpos(2);  
            else
               vcbar_gap = 0.10;  
               cbbottom = 0.50*cbpos(2);
            end
         end
         cbpos = [ cbleft  cbbottom  cbwidth  cbpos(4) ] ;
         %set( colorbar_handle(cb_fig), 'Position', cbpos );

         fpos = fpos_no_cb;
         apos = apos_no_cb;
         fpos(2) = fpos_no_cb(2)-vcbar_gap*fpos_no_cb(4);
         fpos(4) = fpos_no_cb(4)*(1+vcbar_gap);
         set( gcf, 'Position', fpos);

         if ( maximize_display == FALSE ) 

            apos(4) = apos_no_cb(4) * fpos_no_cb(4) / fpos(4);

            %apos(2) = 1.0 - 0.25*(1-apos(4)) - apos(4);
            if fig_has_title == TRUE
               apos(2) = 0.75*(1-apos(4));   
            else
               apos(2) = 0.90*(1-apos(4)); 
            end

            set( gca, 'Position', apos );
         end

         set( colorbar_handle(cb_fig), 'Position', cbpos );
         set( gca, 'Position', apos );   % re-position axis to counter the effects of colorbar re-position

         if length(who('cbar_tick')) == 1
            set( colorbar_handle(cb_fig), 'XTick', cbar_tick );
         end

         if length(who('cbar_ticklabel')) == 1
            set( colorbar_handle(cb_fig), 'XTickLabel', cbar_ticklabel );
         end

      elseif ( color_bar_orientation == 2 )
         colorbar('vert');
         colorbar_handle = findobj( 'Tag', 'Colorbar' );
         %cb_fig = length(colorbar_handle);
         cb_fig = 1;
         cbpos = get( colorbar_handle(cb_fig), 'Position');

         cbpos(3)= 0.025;
         apos = apos_no_cb;
         if ( maximize_display == TRUE ) 
            hcbar_gap = 5.0*cbpos(3);
            cbwidth = color_bar_width;
            cbbottom  = apos(2) + 0.5*(apos(4)-cbwidth);
            cbleft    = 1-3.0*cbpos(3);
         else 
            hcbar_gap = 2.5*cbpos(3);
            cbwidth = color_bar_width * apos(4);
            cbbottom  = apos(2) + 0.5*(apos(4)-cbwidth);
            cbleft    = 1-2.5*cbpos(3);
         end
         cbpos = [ cbleft  cbbottom  cbpos(3) cbwidth ] ;

         fpos = fpos_no_cb;
         fpos(3) = fpos(3)*(1+hcbar_gap);
         set( gcf, 'Position', fpos);

         if ( maximize_display == FALSE ) 
            apos(3) = apos_no_cb(3) * fpos_no_cb(3) / fpos(3);
            set( gca, 'Position', apos );
         end

         set( colorbar_handle(cb_fig), 'Position', cbpos );
         set( gca, 'Position', apos );   % re-position axis to counter the effects of colorbar re-position

         if length(who('cbar_tick')) == 1
            set( colorbar_handle(cb_fig), 'YTick', cbar_tick );
         end

         if length(who('cbar_ticklabel')) == 1
            set( colorbar_handle(cb_fig), 'YTickLabel', cbar_ticklabel );
         end

      else 
         fprintf('\nWARNING:  illegal orientation set for color bar.\n')
         fprintf('            options are 1 for horizontal or 2 for verticle\n')
      end

      fpos = get(gcf, 'Position');
      fpos(1) = fig_pos(1); fpos(2) = fig_pos(2);
      set(gcf, 'Position', fpos);

      if length( who('color_bar_font_size') ) == 1
         set( colorbar_handle, 'FontSize', color_bar_font_size );
      end

      if length( who('color_bar_font_weight') ) == 1
         set( colorbar_handle, 'FontWeight', color_bar_font_weight );
      end

      if ( length(who('logarithmic_plot')) > 0 )
         if ( logarithmic_plot == TRUE ) 
            cbtick      = get( colorbar_handle(cb_fig), 'XTick' ) ;
            log_cbtick  = round(cbtick(1)) : 1 : round(cbtick(length(cbtick)));
            cbticklabel = 10.^log_cbtick;
            set( colorbar_handle(cb_fig), 'XTick'     , log_cbtick  );
            set( colorbar_handle(cb_fig), 'XTickLabel', cbticklabel );
         end
      end


      if vector_plot==TRUE
         delete( colorbar_handle );
      end
