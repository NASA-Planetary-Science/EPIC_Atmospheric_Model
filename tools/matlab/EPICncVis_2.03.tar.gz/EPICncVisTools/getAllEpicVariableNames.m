function all_vars = getAllEpicVariablesNames()

iv = 1;

all_vars(iv).name = 'u';                        iv=iv+1;
all_vars(iv).name = 'v';                        iv=iv+1;
all_vars(iv).name = 'hdry';                     iv=iv+1;
all_vars(iv).name = 'theta';                    iv=iv+1;
all_vars(iv).name = 'nu_turb';                  iv=iv+1;
all_vars(iv).name = 'hdry3';                    iv=iv+1;
all_vars(iv).name = 'pdry3';                    iv=iv+1;
all_vars(iv).name = 'p2';                       iv=iv+1;
all_vars(iv).name = 'p3';                       iv=iv+1;
all_vars(iv).name = 'theta2';                   iv=iv+1;
all_vars(iv).name = 'h2';                       iv=iv+1;
all_vars(iv).name = 'h3';                       iv=iv+1;
all_vars(iv).name = 't2';                       iv=iv+1;
all_vars(iv).name = 't3';                       iv=iv+1;
all_vars(iv).name = 'rho2';                     iv=iv+1;
all_vars(iv).name = 'rho3';                     iv=iv+1;
all_vars(iv).name = 'exner2';                   iv=iv+1;
all_vars(iv).name = 'exner3';                   iv=iv+1;
all_vars(iv).name = 'fgibb2';                   iv=iv+1;
all_vars(iv).name = 'gz2';                      iv=iv+1;
all_vars(iv).name = 'gz3';                      iv=iv+1;
all_vars(iv).name = 'mont2';                    iv=iv+1;
all_vars(iv).name = 'heat3';                    iv=iv+1;
all_vars(iv).name = 'pv2';                      iv=iv+1;
all_vars(iv).name = 'ri2';                      iv=iv+1;
all_vars(iv).name = 'ri3';                      iv=iv+1;
all_vars(iv).name = 'vort2';                    iv=iv+1;
all_vars(iv).name = 'div_uv2';                  iv=iv+1;
all_vars(iv).name = 'w3';                       iv=iv+1;
all_vars(iv).name = 'dzdt3';                    iv=iv+1;
all_vars(iv).name = 'diffusion_coef_uv';        iv=iv+1;
all_vars(iv).name = 'diffusion_coef_theta';     iv=iv+1;
all_vars(iv).name = 'diffusion_coef_mass';      iv=iv+1;
all_vars(iv).name = 'u_spinup';                 iv=iv+1;
all_vars(iv).name = 'ptop';                     iv=iv+1;
all_vars(iv).name = 'gz_surface';               iv=iv+1;

