
fig_pos   = [ 10 10 ];
fig_width = 560;
fig_squeeze_width = 50;

min_color = -3.0;
max_color =  5.0;

color_bar_orientation = 1;   % 1 for horizontal,  2 for vertical
color_bar_font_size   = 13 * max(fig_width)/560;
color_bar_width       = 0.80;

xtick = [-3 -1 1 3 5];
xticklabel = [-30 -10 10 30 50];
%logarithmic_plot = FALSE;          % ( TRUE displays 10^xticklabel )


display_text_box = TRUE;
text_box.name            = 'mol/m^2';
text_box.location        = [ 0.1*(1.0-color_bar_width)  0.5 ];
text_box.font_size       = 14 * max(fig_width)/560;
text_box.character_width = eps;
text_box.background      = 'white';
text_box.edge            = 'none'; 

