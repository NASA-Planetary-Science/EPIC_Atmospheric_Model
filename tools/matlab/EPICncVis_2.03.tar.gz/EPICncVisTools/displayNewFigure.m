if length(who('generate_new_figures'))==0
  generate_new_figures = TRUE;
end

if generate_new_figures
   fig_num = figure;
   cax = newplot;

   set( cax, 'FontSize', AxisFontSize );
   set( gcf, 'Position', fig_size );
end


