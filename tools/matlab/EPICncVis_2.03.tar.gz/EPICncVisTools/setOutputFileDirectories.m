

  %%
  %% Create output directories if necessary (must be done here for AppendSlides option)
  %%
  if length(who('Figures_subdir')) == 0
     Figures_subdir    = 'Figures';
  end
  if length(who('Animations_subdir')) == 0
     Animations_subdir = 'Animations';
  end
  if length( who('PresentationSlides') ) > 0
     if PresentationSlides
        Figures_subdir    = [ Figures_subdir '_Presentations' ];
        %Animations_subdir = [ Animations_subdir '_Presentations' ];
     end
  end

  if length(who('experiment_dir'))
    bmp_file_directory = [write_data_dir planet slash experiment_dir slash Figures_subdir ];
    movie_file_directory = [write_data_dir planet slash experiment_dir slash Animations_subdir  ];
  elseif length(who('planet'))
    bmp_file_directory = [write_data_dir planet slash Figures_subdir ];
    movie_file_directory = [write_data_dir planet slash Animations'  ];
  else
    bmp_file_directory = [write_data_dir Figures_subdir ];
    movie_file_directory = [write_data_dir Animations_subdir  ];
  end

  if strfind(slide_type,'COMPARE-TIMEAVE-')
    bmp_file_directory = [bmp_file_directory slash 'Compare_TimeAve' ];

  elseif strfind(slide_type,'-TIMEAVE-')
    bmp_file_directory = [bmp_file_directory slash 'TimeAve' ];

  else
    bmp_file_directory = [bmp_file_directory slash slide_name_prefix ];
  end



  if isdir(bmp_file_directory)==FALSE
     mkdir(bmp_file_directory);
  end

  if isdir(movie_file_directory)==FALSE
     mkdir(movie_file_directory);
  end


