
function  closest_ind = find_place_in_table( tab, x )

closest_ind = find( x == tab );

if length( closest_ind ) == 0
   igt = find( x > tab );

   if length( igt ) == 0
      error('Can not find place in table')
   else
      closest_ind = igt( length(igt) );
   end

end


%if length( closest_ind ) == 0
%   igt = find( x > tab );
%   ilt = find( x < tab );
%
%   if length( igt )==0  &  length( ilt )==0
%      error('Can not find closest index')
%
%   elseif length( ilt ) == 0
%      closest_ind = igt( length(igt) );
%
%   elseif length( igt ) == 0
%      closest_ind = ilt( 1 );
%
%   else
%      igt = igt( length(igt) );
%      ilt = ilt( 1 );
%
%      igt_diff = abs(tab(igt) - x);
%      ilt_diff = abs(tab(ilt) - x);
%
%      if igt_diff < ilt_diff
%         closest_ind = igt;
%      else
%         closest_ind = ilt;
%      end
%      
%   end
%
%end

