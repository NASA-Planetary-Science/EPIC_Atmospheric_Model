
function HOME_PATH = getHomeDirectory()

%HOME_PATH = '/Users/aherrnst';


tmp_filename = 'home_path';
hm_id = fopen( tmp_filename );

while hm_id ~= -1
   fclose(hm_id);
   tmp_filename = [tmp_filename '0'];
   hm_id = fopen( tmp_filename );
end

unix(['echo $HOME > ' tmp_filename]);

hm_id = fopen( tmp_filename );
HOME_PATH = fgetl( hm_id );
fclose( hm_id );

eval(['delete ' tmp_filename])

