
  %extract_it = [124];

  vector_plot        = FALSE;  
  vector_arrow_scale = 2.0;
  contour_plot       = FALSE; 
  
  spherical_coord_plot  = FALSE;
  value_at_poles        = [0.0];

  scale_data            = 1.0;
  logarithmic_plot      = FALSE;
  min_logarithmic_limit = 1.0e-2;

  shading_type          = 'flat';  
  plot_grid_only        = FALSE;
  
  use_auto_color_map = TRUE;
  zmin = -10;  zmax = 20;
  
  
  fig_pos = [ 50, 375 ];  
  fig_width = 560;         
  alter_fig_width_for_globe = TRUE;
  
  disp_axis           = TRUE;
  maximize_display    = FALSE;
  fill_axis_in_figure = 0.85;
  %left_right_justify  = 0.40;
  %bottom_top_justify  = 0.35;
  AxisFontSize        = 16 * fig_width / 420;

  color_bar_orientation = 1;   % 1 for horizontal,  2 for vertical
  color_bar_width       = 0.750;
  color_bar_font_size   = 12 * fig_width / 560;
  
  display_text_box       = FALSE;
  display_time_text_box  = FALSE;
  display_arrow_text_box = FALSE;

  time_text_box.name            = ' ';
  %time_text_box.location        = [ 0.35*(1.0-color_bar_width)  0.075 ];
  time_text_box.location        = [ 0.01  0.035 ];
  time_text_box.font_size       = 15;
  time_text_box.font_weight     = 'bold';
  time_text_box.character_width = 1;
  time_text_box.background      = 'white';  % 'none'
  time_text_box.edge            = 'none';      % 'none'
  
  clear xtick ytick xticklabel yticklabel
  % comment out the following to turn off
     %xtick = 0 : 90*pi/180 : 360*pi/180;
     %xticklabel = [' 0 '; '90E'; '180'; '90W'; ' 0 '];
     %ytick = -80*pi/180 : 40*pi/180 : 80*pi/180;
     %yticklabel = ['80S'; '40S'; ' 0 '; '40N'; '80N'];


  %movie options
  repeat_num = 1;
  fps        = 1.5;




