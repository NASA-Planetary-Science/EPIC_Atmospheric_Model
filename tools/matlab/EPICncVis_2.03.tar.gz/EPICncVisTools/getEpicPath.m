
function EPIC_PATH = getEpicPath()

%EPIC_PATH = '/Users/aherrnst/epic';


tmp_filename = 'epic_path';
ep_id = fopen( tmp_filename );

while ep_id ~= -1
   fclose(ep_id);
   tmp_filename = [tmp_filename '0'];
   ep_id = fopen( tmp_filename );
end

unix(['echo $EPIC_PATH > ' tmp_filename]);

ep_id = fopen( tmp_filename );
EPIC_PATH = fgetl( ep_id );
fclose( ep_id );

eval(['delete ' tmp_filename])

