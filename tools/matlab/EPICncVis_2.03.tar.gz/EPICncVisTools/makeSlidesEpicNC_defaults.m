%
%  vector_plot        = FALSE;  
%  vector_arrow_scale = 2.0;
%  contour_plot       = FALSE; 
%  
%  spherical_coord_plot  = FALSE;
%  %value_at_poles        = [0.0];
%
%  logarithmic_plot      = FALSE;
%  min_logarithmic_limit = 1.0e-2;
%
%  shading_type          = 'flat';  
%  plot_grid_only        = FALSE;
%  
%  use_auto_color_map = TRUE;
%  zmin = -10;  zmax = 20;
%  
%  
  if length(who('fig_pos')) == 0
    fig_pos = [ 50, 375 ];  
  end
  if length(who('fig_width')) == 0
    fig_width = 560;         
  end
  if length(who('alter_fig_width_for_globe')) == 0
    alter_fig_width_for_globe = TRUE;
  end
  
  if length(who('Title')) == 0
    Title = ' ';
  end
  if length(who('disp_axis')) == 0
    disp_axis           = TRUE;
  end
  if length(who('maximize_display')) == 0
    maximize_display    = FALSE;
  end
  if length(who('fill_axis_in_figure')) == 0
    fill_axis_in_figure = 0.85;
  end
  if length(who('AxisFontSize')) == 0
    AxisFontSize        = 16 * fig_width / 420;
  end
%  %left_right_justify  = 0.40;
%  %bottom_top_justify  = 0.35;

  
  if length(who('color_bar_orientation')) == 0
    color_bar_orientation = 1;   % 1 for horizontal,  2 for vertical
  end
  if length(who('color_bar_width')) == 0
    color_bar_width       = 0.750;
  end
  if length(who('color_bar_font_size')) == 0
    color_bar_font_size   = 12 * fig_width / 560;
  end
  
  if length(who('display_text_box')) == 0
    display_text_box       = FALSE;
  end
  if length(who('display_time_text_box')) == 0
    display_time_text_box  = TRUE;
  end
  if length(who('display_arrow_text_box')) == 0
    display_arrow_text_box = FALSE;
  end


  if length(who('time_text_box')) == 0
    time_text_box.name            = ' ';
    %time_text_box.location        = [ 0.35*(1.0-color_bar_width)  0.075 ];
    time_text_box.units           = 'years';
    time_text_box.location        = [ 0.01  0.035 ];
    time_text_box.font_size       = 15;
    time_text_box.font_weight     = 'bold';
    time_text_box.character_width = 1;
    time_text_box.background      = 'white';  % 'none'
    time_text_box.edge            = 'none';      % 'none'
  else
    if not(isfield(time_text_box,'name'))
      time_text_box.name          = ' ';
    end
    if not(isfield(time_text_box,'units'))
      time_text_box.units         = 'years';
    end
    if not(isfield(time_text_box,'location'))
      time_text_box.location      = [ 0.01  0.035 ];
    end
    if not(isfield(time_text_box,'font_size'))
      time_text_box.font_size     = 15;
    end
    if not(isfield(time_text_box,'font_weight'))
      time_text_box.font_weight   = 'bold';
    end
    if not(isfield(time_text_box,'character_width'))
      time_text_box.character_width = 1;
    end
    if not(isfield(time_text_box,'background'))
      time_text_box.background    = 'white';
    end
    if not(isfield(time_text_box,'edge'))
      time_text_box.edge          = 'none';
    end
  end

  if length(who('arrow_type')) == 0
    if strfind(slide_type, 'SPHERE')
      arrow_type                   = 2;  
    else
      arrow_type                   = 1; 
    end
  end

  if length(who('arrow_legend')) == 0
    arrow_legend.tmp             = -1;
  end

%  if length(who('arrow_legend')) == 0
%    arrow_legend.character_width = 15;
%    arrow_legend.location        = [0.02 0.10];
%    arrow_legend.sig_figs        = 2;
%    arrow_legend.font_size       = 15 * fig_width / 560;
%    arrow_legend.font_weight     = 'bold';
%    arrow_legend.edge            = 'none';
%    arrow_legend.arrow_size      = 30 * fig_width / 560;
%  else
%    if not(isfield(arrow_legend,'character_width')) 
%      arrow_legend.character_width = 15;
%    end
%    if not(isfield(arrow_legend,'location')) 
%      arrow_legend.location        = [0.02 0.10];
%    end
%    if not(isfield(arrow_legend,'sig_figs')) 
%      arrow_legend.sig_figs        = 2;
%    end
%    if not(isfield(arrow_legend,'font_size')) 
%      arrow_legend.font_size       = 15 * fig_width / 560;
%    end
%    if not(isfield(arrow_legend,'font_weight')) 
%      arrow_legend.font_weight     = 'bold';
%    end
%    if not(isfield(arrow_legend,'edge')) 
%      arrow_legend.edge            = 'none';
%    end
%    if not(isfield(arrow_legend,'arrow_size')) 
%      arrow_legend.arrow_size      = 30 * fig_width / 560;
%    end
%  end


