
vars = who;

iv=1;
non_clear_vars(iv).name = 'TRUE';                             iv=iv+1;
non_clear_vars(iv).name = 'FALSE';                            iv=iv+1;
non_clear_vars(iv).name = 'OFF';                              iv=iv+1;
non_clear_vars(iv).name = 'ON';                               iv=iv+1;

non_clear_vars(iv).name = 'slide_type';                       iv=iv+1;
non_clear_vars(iv).name = 'write_figures_to_image_files';     iv=iv+1;
non_clear_vars(iv).name = 'create_mat_movie_file';            iv=iv+1;
non_clear_vars(iv).name = 'slash';                            iv=iv+1;
non_clear_vars(iv).name = 'root_data_dir';                    iv=iv+1;
non_clear_vars(iv).name = 'write_data_dir';                   iv=iv+1;
non_clear_vars(iv).name = 'bmp_file_directory';               iv=iv+1;
non_clear_vars(iv).name = 'movie_file_directory';             iv=iv+1;
non_clear_vars(iv).name = 'imv';                              iv=iv+1;
non_clear_vars(iv).name = 'isp';                              iv=iv+1;
non_clear_vars(iv).name = 'slide_attributes';                 iv=iv+1;
non_clear_vars(iv).name = 'subplot_attributes';               iv=iv+1;
non_clear_vars(iv).name = 'num_diagnostics';                  iv=iv+1;
non_clear_vars(iv).name = 'run_directory';                    iv=iv+1;
non_clear_vars(iv).name = 'load_files_externally';            iv=iv+1;
non_clear_vars(iv).name = 'load_comparisons_externally';      iv=iv+1;
non_clear_vars(iv).name = 'extract_ncfile_externally';        iv=iv+1;
non_clear_vars(iv).name = 'ExtractNCSlides';                  iv=iv+1;
non_clear_vars(iv).name = 'num_slides';                       iv=iv+1;
non_clear_vars(iv).name = 'slide_count';                      iv=iv+1;
non_clear_vars(iv).name = 'extract_it';                       iv=iv+1;
non_clear_vars(iv).name = 'slides_extract_it';                iv=iv+1;
non_clear_vars(iv).name = 'slides_extract_ik';                iv=iv+1;
non_clear_vars(iv).name = 'all_slides_zmin';                  iv=iv+1;
non_clear_vars(iv).name = 'all_slides_zmax';                  iv=iv+1;
non_clear_vars(iv).name = 'slide_name_prefix';                iv=iv+1;
non_clear_vars(iv).name = 'DisplayMaxMin';                    iv=iv+1;
non_clear_vars(iv).name = 'PlotSlidesData';                   iv=iv+1;
non_clear_vars(iv).name = 'starttime_makeSlidesEpicNC';       iv=iv+1;
non_clear_vars(iv).name = 'AppendSlides';                     iv=iv+1;
non_clear_vars(iv).name = 'AppendSloppy';                     iv=iv+1;
non_clear_vars(iv).name = 'PresentationSlides';               iv=iv+1;
non_clear_vars(iv).name = 'last_file';                        iv=iv+1;
non_clear_vars(iv).name = 'makeSlidesEpicNC_overrides';       iv=iv+1;
non_clear_vars(iv).name = 'postSlidePlot';                    iv=iv+1;
non_clear_vars(iv).name = 'data_it';                          iv=iv+1;
non_clear_vars(iv).name = 'at_least_one_fig_plotted';         iv=iv+1;
non_clear_vars(iv).name = 'longitude_slice';                  iv=iv+1;
non_clear_vars(iv).name = 'fig_squeeze_width';                iv=iv+1;
non_clear_vars(iv).name = 'colormap_type';                    iv=iv+1;
non_clear_vars(iv).name = 'auto_close_figures';               iv=iv+1;
non_clear_vars(iv).name = 'output_file_format';               iv=iv+1;

non_clear_vars(iv).name = 'MxN';                              iv=iv+1;
non_clear_vars(iv).name = 'generate_new_figures';             iv=iv+1;
non_clear_vars(iv).name = 'width_height_ratio';               iv=iv+1;
non_clear_vars(iv).name = 'mxn_filename';                     iv=iv+1;
non_clear_vars(iv).name = 'SetMxNinput';                      iv=iv+1;
non_clear_vars(iv).name = 'ExtractNCMxN';                     iv=iv+1;
non_clear_vars(iv).name = 'load_nxm_input_externally';        iv=iv+1;
non_clear_vars(iv).name = 'extract_mxn_ncfile_externally';    iv=iv+1;
non_clear_vars(iv).name = 'fig_num';                          iv=iv+1;
non_clear_vars(iv).name = 'fig_pos_mxn';                      iv=iv+1;
non_clear_vars(iv).name = 'fig_width_mxn';                    iv=iv+1;
non_clear_vars(iv).name = 'background_color';                 iv=iv+1;
non_clear_vars(iv).name = 'velocity_scaling_mxn';             iv=iv+1;
non_clear_vars(iv).name = 'planet';                           iv=iv+1;
non_clear_vars(iv).name = 'root_data_dir';                    iv=iv+1;
non_clear_vars(iv).name = 'experiment_dir';                   iv=iv+1;
non_clear_vars(iv).name = 'check_subplot_time_synch';         iv=iv+1;
non_clear_vars(iv).name = 'sp_time';                          iv=iv+1;
non_clear_vars(iv).name = 'MxN_plot_success';                 iv=iv+1;
non_clear_vars(iv).name = 'compare_subplot';                  iv=iv+1;
non_clear_vars(iv).name = 'Extract_FromMatFile';              iv=iv+1;


clear save_to_tmp
save_to_tmp = 'save non_clear_vars';
for iv=1:length(non_clear_vars)
   if length(who(non_clear_vars(iv).name))==1
      save_to_tmp = [ save_to_tmp ' ' non_clear_vars(iv).name];
   end
end
eval(save_to_tmp)
clear

load non_clear_vars
delete non_clear_vars.mat

