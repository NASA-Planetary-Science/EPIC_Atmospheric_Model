%clear

%
% Definitions
%
run_directory = pwd;

TRUE=1; FALSE=0;
OFF = 0; ON=1;

SetFile       = TRUE;
SetInput      = TRUE;
SetOutput     = TRUE;
ExtractNCdata = TRUE; 
ProducePlot   = TRUE;

% the following options are set prior to executing this script
load_files_externally_exists       = length( who('load_files_externally') );
load_input_externally_exists       = length( who('load_input_externally') );
load_comparisons_externally_exists = length( who('load_comparisons_externally') );
extract_ncfile_externally_exists   = length( who('extract_ncfile_externally') );
produce_plot_externally_exists     = length( who('produce_plot_externally') );
  
if ( load_files_externally_exists==TRUE )
   if ( load_files_externally==TRUE )
      SetFile = FALSE;
   end
end

if ( load_input_externally_exists==TRUE )
   if ( load_input_externally==TRUE )
      SetInput = FALSE;
   end
end

if ( load_comparisons_externally_exists==TRUE )
   if ( load_comparisons_externally==TRUE )
      SetOutput = FALSE;
   end
end

if ( extract_ncfile_externally_exists==TRUE )
   if ( extract_ncfile_externally==TRUE )
      ExtractNCdata = FALSE;
   end
end

if ( produce_plot_externally_exists==TRUE )
   if ( produce_plot_externally==TRUE )
      ProducePlot = FALSE;
   end
end

checkEPICncPATHs

