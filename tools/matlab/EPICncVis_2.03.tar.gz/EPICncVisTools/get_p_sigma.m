function ps = get_p_sigma(pbot, sigma, ptop)
%
% Inverse of get_sigma() function.  If one is changed, the other should
% be changed accordingly.
%
% (code translated from epic_funcs_diag.c)
%

  ps = pbot*exp(sigma*log(ptop/pbot));



