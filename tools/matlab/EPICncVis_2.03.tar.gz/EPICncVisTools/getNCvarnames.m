function out = getNCvarnames( nc_file_input )

if nargin<1
  error(' Missing input: nc_file')
end

if ischar( nc_file_input )
  nc_file = netcdf( nc_file_input );
else
  nc_file = nc_file_input;
end


variables = var(nc_file);

for v=1:length(variables)
  out(v).name = name( variables{v} );
end


return

