function [cs chan] = contourpm( x, y, data, cont_lines )
%
% function [cs chan] = contourpm( x, y, data, cont_lines )
%
% Plots contours using the Matlab tool "contour", and 
%  then alters negative isolines to be displayed as dashed.
%

[cs chan]=contour( x, y, data, cont_lines);

%cont_levels = get(chan, 'LevelList');
cont_ids    = get(chan, 'Children' );
for icd=1:length(cont_ids)
  cont_value = get(cont_ids(icd), 'FaceVertexCData');

  if min(cont_value) < 0
    %set( cont_ids(icd), 'LineStyle', ':' );
    set( cont_ids(icd), 'LineStyle', '--' );
  else
    %line_width = get( cont_ids(icd), 'LineWidth' );
    %set( cont_ids(icd), 'LineWidth', 4*line_width );
    %set( cont_ids(icd), 'LineStyle', '-' );
  end
end


