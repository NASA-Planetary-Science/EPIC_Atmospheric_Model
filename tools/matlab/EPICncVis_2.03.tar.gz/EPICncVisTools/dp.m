function dp(val)
% function displays a value up to 16 decimals places

fprintf('%10.16f\n',val)
%fprintf('%20.20f\n',val)

return
